package com.dirkficial.task;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DirkficialTaskAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(DirkficialTaskAppApplication.class, args);
	}

}
