package com.dirkficial.task;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DirkficialTaskAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
